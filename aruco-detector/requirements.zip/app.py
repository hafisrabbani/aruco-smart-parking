import cv2
import numpy as np
import tkinter as tk
from tkinter import Label, Button, OptionMenu, StringVar
from PIL import Image, ImageTk


class ArucoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ArUco Detector")
        self.root.geometry("900x700")

        # Pilihan kamera
        self.selected_cam = StringVar(value="0")
        self.cam_menu = OptionMenu(root, self.selected_cam, "0", "1", "2", "3")
        self.cam_menu.pack(pady=5)

        self.start_button = Button(root, text="Start Camera", command=self.start_camera)
        self.start_button.pack(pady=5)

        # Label video
        self.video_label = Label(root)
        self.video_label.pack()

        # Label status marker
        self.status_label = Label(root, text="Pilih kamera lalu klik Start Camera", font=("Arial", 14))
        self.status_label.pack(pady=10)

        # Tombol keluar
        self.quit_button = Button(root, text="Quit", command=self.close)
        self.quit_button.pack(pady=5)

        # Setup ArUco
        self.aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_6X6_1000)
        parameters = cv2.aruco.DetectorParameters()
        self.detector = cv2.aruco.ArucoDetector(self.aruco_dict, parameters)

        # Kamera
        self.cap = None
        self.last_ids = None

    def start_camera(self):
        cam_index = int(self.selected_cam.get())
        if self.cap and self.cap.isOpened():
            self.cap.release()

        self.cap = cv2.VideoCapture(cam_index)
        if not self.cap.isOpened():
            self.status_label.config(text=f"Kamera {cam_index} tidak bisa diakses")
            return

        self.status_label.config(text=f"Kamera {cam_index} aktif. Cari marker...")
        self.last_ids = None
        self.update_frame()

    def update_frame(self):
        if not self.cap or not self.cap.isOpened():
            return

        ret, frame = self.cap.read()
        if not ret:
            self.status_label.config(text="Gagal membaca kamera")
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, rejected = self.detector.detectMarkers(gray)

        if ids is not None:
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)
            if self.last_ids is None or not (ids.flatten() == self.last_ids).all():
                print("Marker terdeteksi dengan ID:", ids.flatten())
                self.status_label.config(text=f"Marker ID: {ids.flatten().tolist()}")
                self.last_ids = ids.flatten()
        else:
            if self.last_ids is not None:
                print("Marker hilang dari frame")
            self.status_label.config(text="Tidak ada marker")
            self.last_ids = None

        # Convert OpenCV image ke Tkinter
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb_frame)
        imgtk = ImageTk.PhotoImage(image=img)
        self.video_label.imgtk = imgtk
        self.video_label.configure(image=imgtk)

        # Panggil lagi setiap 10ms
        self.root.after(10, self.update_frame)

    def close(self):
        if self.cap and self.cap.isOpened():
            self.cap.release()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = ArucoApp(root)
    root.mainloop()
